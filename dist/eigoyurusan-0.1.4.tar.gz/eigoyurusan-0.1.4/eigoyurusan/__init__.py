"""Top-level package for eigoyurusan."""

__author__ = """Sora Takashima"""
__email__ = 'soraemonpockt@gmail.com'
__version__ = '0.1.0'